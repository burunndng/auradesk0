/**
 * AXIS Waiting
 * "Go do your thing" - session active, waiting for user to complete the experience
 */

import React from 'react';
import type { AXISSession } from '../../../../types';

interface AXISWaitingProps {
  session: AXISSession;
  onReady: () => void;
  onBack: () => void;
  onCancel: () => void;
}

export default function AXISWaiting({ session, onReady, onBack, onCancel }: AXISWaitingProps) {
  return (
    <div className="space-y-6 max-w-2xl">
      {/* Status */}
      <div className="bg-slate-900/50 border border-slate-700 rounded-lg p-6 text-center">
        <div className="text-sm text-slate-400 mb-2 uppercase tracking-wider font-semibold">
          Session Active
        </div>
        <h2 className="text-2xl font-serif text-amber-50 mb-4">{session.title}</h2>
      </div>

      {/* Session Info */}
      <div className="space-y-3">
        <div>
          <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold mb-1">
            Intention
          </p>
          <p className="text-slate-300 leading-relaxed">{session.intention}</p>
        </div>
        {session.successCriteria && (
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold mb-1">
              Success Criteria
            </p>
            <p className="text-slate-300 leading-relaxed">{session.successCriteria}</p>
          </div>
        )}
      </div>

      {/* Instructions */}
      <div className="bg-slate-900/30 border border-slate-800 rounded-lg p-4 text-center">
        <p className="text-slate-300 leading-relaxed mb-1">Go do your thing.</p>
        <p className="text-slate-400 text-sm">
          When you're ready, come back and capture what mattered.
        </p>
      </div>

      {/* Buttons */}
      <div className="space-y-2">
        <button
          onClick={onReady}
          className="w-full px-4 py-3 bg-amber-600 text-amber-50 rounded-lg hover:bg-amber-500 transition-colors font-medium"
        >
          I'm Done — Ready to Reflect
        </button>
        <button
          onClick={onCancel}
          className="w-full px-4 py-3 bg-slate-800 text-slate-100 rounded-lg hover:bg-slate-700 transition-colors font-medium"
        >
          Cancel Session
        </button>
      </div>
    </div>
  );
}

/**
 * AXIS Mode Picker
 * Choose between native AI conversation or bridge to external AI
 */

import React from 'react';

interface Props {
  previousSynthesis?: any;
  onStartNative: () => void;
  onStartBridge: () => void;
  onBack: () => void;
}

export default function AXISModePicker({
  previousSynthesis,
  onStartNative,
  onStartBridge,
  onBack,
}: Props) {
  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h3 className="text-sm font-semibold text-amber-200 mb-4 uppercase tracking-wider">
          How would you like to work with AXIS?
        </h3>

        {/* Mode Options */}
        <div className="space-y-2">
          <button
            onClick={onStartNative}
            className="w-full px-4 py-3 bg-purple-900/40 border border-purple-700/60 hover:border-purple-500 rounded-lg text-left transition-colors"
          >
            <p className="text-sm font-medium text-purple-200">Chat in AXIS</p>
            <p className="text-xs text-slate-400 mt-0.5">AI-guided session inside the app</p>
          </button>
          <button
            onClick={onStartBridge}
            className="w-full px-4 py-3 bg-slate-800/60 border border-slate-700 hover:border-slate-500 rounded-lg text-left transition-colors"
          >
            <p className="text-sm font-medium text-slate-200">Bridge to External AI</p>
            <p className="text-xs text-slate-400 mt-0.5">Copy prompts to Claude, ChatGPT, etc.</p>
          </button>
        </div>

        {/* Previous Synthesis Card */}
        {previousSynthesis && (
          <div className="bg-purple-900/20 border border-purple-800/30 rounded-lg p-3 mt-4">
            <p className="text-xs text-purple-400 uppercase tracking-wider mb-1">Last Session</p>
            <p className="text-sm text-slate-300 leading-relaxed">{previousSynthesis.sessionFindings?.keyInsight}</p>
            {previousSynthesis.openThreads?.[0] && (
              <p className="text-xs text-slate-500 mt-1">Still open: {previousSynthesis.openThreads[0]}</p>
            )}
          </div>
        )}
      </div>

      {/* Back Button */}
      <div className="pt-4 border-t border-slate-700">
        <button
          onClick={onBack}
          className="text-xs text-slate-500 hover:text-slate-300"
        >
          ← Back to framing
        </button>
      </div>
    </div>
  );
}

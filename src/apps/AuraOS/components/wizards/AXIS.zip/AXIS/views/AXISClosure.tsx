/**
 * AXIS Closure
 * Session completion - close or keep open
 */

import React from 'react';
import { CheckCircle } from 'lucide-react';
import type { AXISSession } from '../../../../types';

interface AXISClosureProps {
  session: AXISSession;
  onClose: () => void;
  onKeepOpen: () => void;
}

export default function AXISClosure({ session, onClose, onKeepOpen }: AXISClosureProps) {
  return (
    <div className="space-y-6 max-w-2xl text-center">
      {/* Success Indicator */}
      <div className="flex justify-center">
        <CheckCircle className="w-12 h-12 text-emerald-400" />
      </div>

      {/* Message */}
      <div>
        <h2 className="text-2xl font-serif text-amber-50 mb-2">Reflection Saved</h2>
        <p className="text-slate-400">Your insight has been captured.</p>
      </div>

      {/* Session Info */}
      <div className="bg-slate-900/50 border border-slate-700 rounded-lg p-4 text-left">
        <p className="text-sm text-slate-500 uppercase tracking-wider font-semibold mb-2">
          Session
        </p>
        <p className="text-amber-50 font-serif text-lg mb-3">{session.title}</p>
        <p className="text-sm text-slate-400">{session.intention}</p>
      </div>

      {/* Decision */}
      <div className="bg-slate-900/30 border border-slate-800 rounded-lg p-4">
        <p className="text-sm text-slate-300 mb-4">Is this session complete?</p>
        <div className="space-y-2">
          <button
            onClick={onClose}
            className="w-full px-4 py-3 bg-amber-600 text-amber-50 rounded-lg hover:bg-amber-500 transition-colors font-medium"
          >
            Close Session
          </button>
          <button
            onClick={onKeepOpen}
            className="w-full px-4 py-3 bg-slate-800 text-slate-100 rounded-lg hover:bg-slate-700 transition-colors font-medium"
          >
            Keep Open
          </button>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs text-slate-500 mt-3">
          <div className="text-center">This topic is resolved for now.</div>
          <div className="text-center">I'll return to this later.</div>
        </div>
      </div>

      {/* Help Text */}
      <p className="text-xs text-slate-500 italic">
        Your reflection is saved to your Insights. You can return anytime.
      </p>
    </div>
  );
}

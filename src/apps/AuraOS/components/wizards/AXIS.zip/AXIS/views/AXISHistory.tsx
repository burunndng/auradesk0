/**
 * AXIS History
 * Session history with filtering and session cards
 */

import React, { useState } from 'react';
import { ChevronLeft } from 'lucide-react';
import type { AXISSession } from '../../../../types';
import AXISSessionCard from '../components/AXISSessionCard';

interface AXISHistoryProps {
  sessions: AXISSession[];
  onBack: () => void;
  onSelectSession: (session: AXISSession) => void;
}

type FilterTab = 'main' | 'open' | 'closed' | 'off-axis';

export default function AXISHistory({ sessions, onBack, onSelectSession }: AXISHistoryProps) {
  const [filterTab, setFilterTab] = useState<FilterTab>('main');

  const mainSessions = sessions.filter(s => !s.isOffAxis);
  const offAxisSessions = sessions.filter(s => s.isOffAxis);

  const filteredSessions = (() => {
    if (filterTab === 'open') return mainSessions.filter(s => s.status !== 'closed');
    if (filterTab === 'closed') return mainSessions.filter(s => s.status === 'closed');
    if (filterTab === 'off-axis') return offAxisSessions;
    return mainSessions;
  })();

  const openCount = mainSessions.filter(s => s.status !== 'closed').length;
  const closedCount = mainSessions.filter(s => s.status === 'closed').length;

  const tabs: Array<{ value: FilterTab; label: string; count: number }> = [
    { value: 'main', label: 'Main', count: mainSessions.length },
    { value: 'open', label: 'Open', count: openCount },
    { value: 'closed', label: 'Closed', count: closedCount },
    { value: 'off-axis', label: 'Side Quests', count: offAxisSessions.length },
  ];

  return (
    <div className="space-y-6 max-w-2xl">
      {/* Header */}
      <div>
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-400 hover:text-slate-300 transition-colors mb-4"
        >
          <ChevronLeft size={18} />
          <span className="text-sm">Back</span>
        </button>
        <h2 className="text-2xl font-serif text-amber-50 mb-1">Session History</h2>
        <p className="text-slate-400 text-sm">Review your past reflections and open sessions</p>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2">
        {tabs.map(tab => (
          <button
            key={tab.value}
            onClick={() => setFilterTab(tab.value)}
            className={`px-3 py-1 text-sm rounded-lg transition-colors ${
              filterTab === tab.value
                ? 'bg-amber-600 text-amber-50'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {tab.label} <span className="text-xs opacity-70">({tab.count})</span>
          </button>
        ))}
      </div>

      {/* Sessions List */}
      {filteredSessions.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-slate-400 text-sm">
            {filterTab === 'main' && 'No sessions yet. Start one to begin.'}
            {filterTab === 'open' && 'No open sessions.'}
            {filterTab === 'closed' && 'No closed sessions yet.'}
            {filterTab === 'off-axis' && 'No side quest sessions yet.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredSessions
            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
            .map(session => (
              <AXISSessionCard
                key={session.id}
                session={session}
                onSelect={() => onSelectSession(session)}
              />
            ))}
        </div>
      )}
    </div>
  );
}

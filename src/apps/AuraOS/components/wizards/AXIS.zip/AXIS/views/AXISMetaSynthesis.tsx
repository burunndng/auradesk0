/**
 * AXIS Meta-Mirror
 * Macro-synthesis trajectory report — auto-triggers after every 5th closed session.
 * Surfaces emerging patterns, stuck points, language shifts, outgrown beliefs, and arc.
 */

import React, { useEffect, useState } from 'react';
import type { AXISSession, AXISAnchor, AXISMetaSynthesis as AXISMetaSynthesisType } from '../../../../types';
import { generateMetaSynthesis } from '../../../../services/AXISService';

interface AXISMetaSynthesisProps {
  sessions: AXISSession[];
  anchor: AXISAnchor;
  onComplete: () => void;
}

export default function AXISMetaSynthesisView({
  sessions,
  anchor,
  onComplete,
}: AXISMetaSynthesisProps) {
  const [report, setReport] = useState<AXISMetaSynthesisType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  useEffect(() => {
    let cancelled = false;

    async function run() {
      try {
        // Collect the last 5 closed, non-off-axis briefs
        const briefs = sessions
          .filter(s => s.status === 'closed' && !s.isOffAxis && s.synthesisBrief)
          .sort((a, b) => new Date(b.closedAt ?? b.createdAt).getTime() - new Date(a.closedAt ?? a.createdAt).getTime())
          .slice(0, 5)
          .map(s => s.synthesisBrief!);

        if (briefs.length === 0) {
          if (!cancelled) { setError(true); setLoading(false); }
          return;
        }

        const generated = await generateMetaSynthesis(briefs, anchor);
        if (!cancelled) {
          setReport(generated);
          setLoading(false);
        }
      } catch (err) {
        console.error('[AXISMetaSynthesis] Error generating meta-synthesis:', err);
        if (!cancelled) { setError(true); setLoading(false); }
      }
    }

    run();
    return () => { cancelled = true; };
  }, [sessions, anchor, retryCount]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-4">
        <div className="w-8 h-8 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
        <p className="text-slate-400 text-sm">Generating trajectory report…</p>
      </div>
    );
  }

  if (error || !report) {
    return (
      <div className="flex flex-col items-center gap-6 py-12 px-4">
        <p className="text-slate-300 text-center text-sm">
          Trajectory report failed. You can skip and continue.
        </p>
        <div className="flex gap-3">
          <button
            onClick={() => { setError(false); setLoading(true); setRetryCount(c => c + 1); }}
            className="px-6 py-2 rounded-lg bg-purple-700 hover:bg-purple-600 text-white text-sm transition-colors"
          >
            Retry
          </button>
          <button
            onClick={onComplete}
            className="px-6 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm transition-colors"
          >
            Skip
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5 px-4 py-6 max-w-2xl mx-auto">
      <div className="text-center">
        <h2 className="text-lg font-serif text-purple-300">Trajectory Report</h2>
        <p className="text-xs text-slate-500 mt-1">Meta-mirror across your last sessions</p>
      </div>

      {/* Overall Arc */}
      {report.trajectoryReport && (
        <div className="rounded-lg border border-purple-700/40 bg-purple-950/20 px-4 py-3">
          <h3 className="text-xs uppercase tracking-widest text-purple-400 mb-2">Your Arc</h3>
          <p className="text-slate-200 text-sm leading-relaxed">{report.trajectoryReport}</p>
        </div>
      )}

      {/* Emerging Patterns */}
      {report.emergingPatterns && (
        <div className="flex flex-col gap-1.5">
          <h3 className="text-xs uppercase tracking-widest text-slate-500">Emerging Patterns</h3>
          <p className="text-slate-300 text-sm leading-relaxed">{report.emergingPatterns}</p>
        </div>
      )}

      {/* Stuck Points */}
      {report.stuckPoints && (
        <div className="flex flex-col gap-1.5">
          <h3 className="text-xs uppercase tracking-widest text-amber-500/80">Stuck Points</h3>
          <p className="text-slate-300 text-sm leading-relaxed">{report.stuckPoints}</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Language Shift */}
        {report.languageShift && (
          <div className="bg-slate-800/40 border border-slate-700/40 rounded-lg p-3">
            <h3 className="text-xs uppercase tracking-widest text-slate-500 mb-1">Language Shift</h3>
            <p className="text-slate-300 text-xs leading-relaxed">{report.languageShift}</p>
          </div>
        )}

        {/* Outgrown Beliefs */}
        {report.outgrownBeliefs && (
          <div className="bg-slate-800/40 border border-slate-700/40 rounded-lg p-3">
            <h3 className="text-xs uppercase tracking-widest text-slate-500 mb-1">Outgrown</h3>
            <p className="text-slate-300 text-xs leading-relaxed">{report.outgrownBeliefs}</p>
          </div>
        )}
      </div>

      {/* Anchor Review Prompt */}
      {report.anchorReviewPrompt && (
        <div className="rounded-lg border border-amber-700/40 bg-amber-950/20 px-4 py-3">
          <h3 className="text-xs uppercase tracking-widest text-amber-400 mb-2">Anchor Check-in</h3>
          <p className="text-amber-200/90 text-sm italic">"{report.anchorReviewPrompt}"</p>
        </div>
      )}

      <div className="pt-2 flex justify-center">
        <button
          onClick={onComplete}
          className="px-8 py-2.5 rounded-lg bg-purple-700 hover:bg-purple-600 text-white text-sm font-medium transition-colors"
        >
          Continue
        </button>
      </div>
    </div>
  );
}

import React, { useEffect, useState } from 'react';
import { AXISSession, AXISAnchor, AXISConversationMessage, AXISSynthesisBrief } from '../../../../types';
import { generateSynthesisBrief, saveSessionToSupabase, UUID_RE } from '../../../../services/AXISService';
import { writeLatestSynthesis } from '../../../../services/AXISStorage';

const EMPTY_BRIEF: AXISSynthesisBrief = {
  userPatterns: { coreDynamic: '', typicalDefenses: '', blindSpots: '', triggers: '' },
  sessionFindings: { presentingToRoot: '', keyInsight: '', shift: 'No', successCriteriaMet: 'Unmet' },
  analystNotes: { effective: '', avoid: '' },
  openThreads: [],
  nextSession: { entryPoint: '', hypothesisToTest: '' },
  cumulativeContext: '',
  persistentCoreTruths: [],
  generatedAt: new Date().toISOString(),
};

interface AXISSynthesisProps {
  session: AXISSession;
  anchor: AXISAnchor;
  conversationHistory: AXISConversationMessage[];
  userId: string;
  previousSynthesis?: AXISSynthesisBrief | null;
  onComplete: (brief: AXISSynthesisBrief) => void;
}

export default function AXISSynthesis({
  session,
  anchor,
  conversationHistory,
  userId,
  previousSynthesis,
  onComplete,
}: AXISSynthesisProps) {
  const [brief, setBrief] = useState<AXISSynthesisBrief | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [saveStatus, setSaveStatus] = useState<'saving' | 'saved' | 'failed' | null>(null);
  const [userAnnotation, setUserAnnotation] = useState('');

  const handleRetry = () => {
    setError(false);
    setLoading(true);
    setRetryCount(c => c + 1);
  };

  useEffect(() => {
    let cancelled = false;

    async function run() {
      try {
        const generated = await generateSynthesisBrief(
          conversationHistory,
          session.refinedIntention || session.intention,
          anchor,
          session.successCriteria,
          session.activityType,
          previousSynthesis,
        );
        if (cancelled) return;

        const updatedSession: AXISSession = {
          ...session,
          synthesisBrief: generated,
          status: 'closed',
          closedAt: new Date().toISOString(),
        };

        if (UUID_RE.test(userId)) {
          setSaveStatus('saving');
          // Synthesis is saved to Supabase via saveSessionToSupabase (includes synthesisBrief field)
          const saved = await saveSessionToSupabase(updatedSession, userId);
          if (cancelled) return;
          setSaveStatus(saved ? 'saved' : 'failed');
        } else {
          // Anon user — persist to IndexedDB so loadPreviousSynthesis can find it
          await writeLatestSynthesis(generated);
          setSaveStatus('saved');
        }

        setBrief(generated);
      } catch (err) {
        console.error('[AXISSynthesis] Error generating synthesis:', err);
        if (!cancelled) setError(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    run();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session.id, anchor.content, conversationHistory, userId, retryCount]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-4">
        <div className="w-8 h-8 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
        <p className="text-slate-400 text-sm">Generating session brief…</p>
      </div>
    );
  }

  if (error || !brief) {
    return (
      <div className="flex flex-col items-center gap-6 py-12 px-4">
        <p className="text-slate-300 text-center text-sm">
          Brief generation failed. Your session data is preserved.
        </p>
        <div className="flex gap-3">
          <button
            onClick={handleRetry}
            className="px-6 py-2 rounded-lg bg-purple-700 hover:bg-purple-600 text-white text-sm transition-colors"
          >
            Retry
          </button>
          <button
            onClick={() => onComplete({ ...EMPTY_BRIEF, generatedAt: new Date().toISOString() })}
            className="px-6 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm transition-colors"
          >
            Skip
          </button>
        </div>
      </div>
    );
  }

  const downloadBriefAsMarkdown = () => {
    if (!brief) return;

    const content = `# AXIS Session Brief: ${session.title || 'Untitled Session'}
Date: ${new Date(brief.generatedAt || Date.now()).toLocaleDateString()}

## Key Insight
${brief.sessionFindings?.keyInsight || 'N/A'}

## Presenting → Root
${brief.sessionFindings?.presentingToRoot || 'N/A'}

## Shift
${brief.sessionFindings?.shift || 'N/A'}

## Success Criteria Met
${brief.sessionFindings?.successCriteriaMet || 'N/A'}

## Open Threads
${brief.openThreads?.map(t => `- ${t}`).join('\n') || 'None'}

## Next Session
Entry Point: ${brief.nextSession?.entryPoint || 'N/A'}
Hypothesis: ${brief.nextSession?.hypothesisToTest || 'N/A'}

## Behavioral Commitment
${brief.behavioralCommitment || 'None'}

## User Patterns
Core Dynamic: ${brief.userPatterns?.coreDynamic || 'N/A'}
Blind Spots: ${brief.userPatterns?.blindSpots || 'N/A'}
Protective Patterns: ${brief.userPatterns?.typicalDefenses || 'N/A'}
Triggers: ${brief.userPatterns?.triggers || 'N/A'}

## Patterns You've Named
${brief.persistentCoreTruths?.map(t => `- ${t}`).join('\n') || 'None'}

## Analyst Notes
What Worked: ${brief.analystNotes?.effective || 'N/A'}
What to Avoid: ${brief.analystNotes?.avoid || 'N/A'}

${userAnnotation.trim() ? `## User Note\n${userAnnotation.trim()}\n` : ''}
`;

    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `axis-brief-${new Date().toISOString().split('T')[0]}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const sf = brief.sessionFindings;
  const up = brief.userPatterns;
  const ns = brief.nextSession;
  const an = brief.analystNotes;

  return (
    <div className="flex flex-col gap-5 px-4 py-6 max-w-2xl mx-auto">
      <h2 className="text-lg font-serif text-purple-300 text-center">Session Brief</h2>

      {/* Key Insight */}
      {sf?.keyInsight && (
        <div className="flex flex-col gap-1.5">
          <h3 className="text-xs uppercase tracking-widest text-slate-500">Key Insight</h3>
          <p className="text-slate-100 text-base font-semibold leading-snug">{sf.keyInsight}</p>
        </div>
      )}

      {/* Presenting → Root */}
      {sf?.presentingToRoot && (
        <div className="flex flex-col gap-1.5">
          <h3 className="text-xs uppercase tracking-widest text-slate-500">Presenting → Root</h3>
          <p className="text-slate-300 text-sm leading-relaxed">{sf.presentingToRoot}</p>
        </div>
      )}

      {/* Shift + Success */}
      <div className="grid grid-cols-2 gap-3">
        {sf?.shift && (
          <div className="bg-slate-800/40 border border-slate-700/40 rounded-lg p-3">
            <h3 className="text-xs uppercase tracking-widest text-slate-500 mb-1">Shift</h3>
            <p className="text-slate-300 text-sm">{sf.shift}</p>
          </div>
        )}
        {sf?.successCriteriaMet && (
          <div className="bg-slate-800/40 border border-slate-700/40 rounded-lg p-3">
            <h3 className="text-xs uppercase tracking-widest text-slate-500 mb-1">Criteria</h3>
            <p className="text-slate-300 text-sm">{sf.successCriteriaMet}</p>
          </div>
        )}
      </div>

      {/* Open Threads */}
      {brief.openThreads?.length > 0 && (
        <div className="flex flex-col gap-1.5">
          <h3 className="text-xs uppercase tracking-widest text-slate-500">Open Threads</h3>
          <ul className="flex flex-col gap-1 list-disc list-inside">
            {brief.openThreads.map((t, i) => (
              <li key={i} className="text-slate-300 text-sm">{t}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Next Session */}
      {(ns?.entryPoint || ns?.hypothesisToTest) && (
        <div className="rounded-lg border border-purple-700/50 bg-purple-950/40 px-4 py-3 flex flex-col gap-2">
          <h3 className="text-xs uppercase tracking-widest text-purple-400">Next Session</h3>
          {ns.entryPoint && (
            <p className="text-purple-200 text-sm italic">"{ns.entryPoint}"</p>
          )}
          {ns.hypothesisToTest && (
            <p className="text-purple-300/70 text-xs">Hypothesis: {ns.hypothesisToTest}</p>
          )}
        </div>
      )}

      {/* Behavioral Commitment */}
      {brief.behavioralCommitment && (
        <div className="flex flex-col gap-1.5">
          <h3 className="text-xs uppercase tracking-widest text-slate-500">Behavioral Commitment</h3>
          <p className="text-slate-300 text-sm">{brief.behavioralCommitment}</p>
        </div>
      )}

      {/* User Patterns (collapsed summary) */}
      {up?.coreDynamic && (
        <div className="flex flex-col gap-1.5">
          <h3 className="text-xs uppercase tracking-widest text-slate-500">Core Dynamic</h3>
          <p className="text-slate-400 text-sm">{up.coreDynamic}</p>
        </div>
      )}

      {/* Persistent Core Truths */}
      {brief.persistentCoreTruths?.length > 0 && (
        <div className="flex flex-col gap-1.5">
          <h3 className="text-xs uppercase tracking-widest text-slate-500">Patterns You've Named</h3>
          <ul className="flex flex-col gap-1 list-disc list-inside">
            {brief.persistentCoreTruths.map((t, i) => (
              <li key={i} className="text-purple-200/80 text-sm">{t}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Analyst Notes */}
      {(an?.effective || an?.avoid) && (
        <div className="grid grid-cols-2 gap-3 text-xs">
          {an.effective && (
            <div className="bg-emerald-950/30 border border-emerald-800/30 rounded-lg p-2.5">
              <p className="text-emerald-400 uppercase tracking-wider mb-1">Worked</p>
              <p className="text-slate-300">{an.effective}</p>
            </div>
          )}
          {an.avoid && (
            <div className="bg-red-950/30 border border-red-800/30 rounded-lg p-2.5">
              <p className="text-red-400 uppercase tracking-wider mb-1">Avoid</p>
              <p className="text-slate-300">{an.avoid}</p>
            </div>
          )}
        </div>
      )}

      {/* User Annotation */}
      <div className="flex flex-col gap-1.5">
        <h3 className="text-xs uppercase tracking-widest text-slate-500">Your Note (optional)</h3>
        <textarea
          value={userAnnotation}
          onChange={e => setUserAnnotation(e.target.value)}
          placeholder="Add a correction, context, or note about this brief…"
          rows={2}
          className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 text-sm placeholder:text-slate-600 focus:outline-none focus:border-purple-600 resize-none"
        />
      </div>

      <div className="pt-2 flex flex-col items-center gap-2">
        {saveStatus === 'saved' && (
          <p className="text-xs text-emerald-400">✓ Session saved to your history</p>
        )}
        {saveStatus === 'failed' && (
          <p className="text-xs text-amber-400">⚠ Couldn't save — copy your brief before closing</p>
        )}
        <div className="flex gap-3 w-full max-w-sm">
          <button
            onClick={downloadBriefAsMarkdown}
            className="flex-1 px-4 py-2.5 rounded-lg border border-purple-500/30 hover:bg-purple-900/30 text-purple-200 text-sm font-medium transition-colors"
          >
            Download .md
          </button>
          <button
            onClick={() => onComplete({ ...brief, userAnnotation: userAnnotation.trim() || undefined })}
            className="flex-1 px-4 py-2.5 rounded-lg bg-purple-700 hover:bg-purple-600 text-white text-sm font-medium transition-colors"
          >
            Complete Session
          </button>
        </div>
      </div>
    </div>
  );
}

/**
 * AXIS Bridge
 * Display both prompts (context package + synthesis prompt) for AI conversation
 * Location: components/wizards/AXIS/views/AXISBridge.tsx
 */

import React, { useState, useMemo } from 'react';
import { ChevronLeft, Copy, Check, MessageSquare, FileText } from 'lucide-react';
import type { AXISSession } from '../../../../types';
import { useAXISAnchor } from '../hooks/useAXISAnchor';

interface AXISBridgeProps {
  session: AXISSession;
  onComplete: () => void;
  onBack: () => void;
  contextData?: any;
}

const synthesisPrompt = `# Session Continuity Brief

## Instructions

End exploration. Generate a **Continuity Brief** for LLM context seeding.

This output will be stored and fed as context to a future LLM session. Optimize for:
- **Density** — token-efficient, no filler
- **Parseability** — structured data, not narrative prose
- **Actionable intelligence** — what the next analyst needs to continue effectively

**Constraints:**
- Maximum 300 words
- No emotional language or affirmations
- Assume the reader is an LLM, not the user
- Use bullet points and key-value structure

---

## Output Structure

### User Patterns
- **Core Dynamic:** [Primary psychological/behavioral pattern driving this topic]
- **Typical Defenses:** [How user avoids, deflects, or rationalizes]
- **Blind Spots:** [What user consistently fails to see]
- **Triggers:** [Topics or framings that provoke resistance]

### Session Findings
- **Presenting → Root:** [What they said → What it actually was — one line each]
- **Key Insight:** [Single most important realization]
- **Shift:** [Yes/No. If yes: what changed]
- **Success Criteria:** [Met / Partial / Unmet — one line why]

### Analyst Notes
- **Effective:** [Approaches, framings, or challenges that landed]
- **Avoid:** [What didn't work or triggered shutdown]

### Open Threads
- [Unresolved thread 1]
- [Unresolved thread 2, if applicable]

### Next Session
- **Entry Point:** [Specific question or angle to open with]
- **Hypothesis to Test:** [Pattern or assumption worth probing further]

### Cumulative Context
[If prior briefs exist: note trajectory, escalating/resolving patterns, recurring themes. If first session: "Baseline session — no prior context."]

---

**INSTRUCTIONS:**
Generate this brief now. Be surgical. Optimize for future LLM parsing.`;

export default function AXISBridge({ session, onComplete, onBack, contextData }: AXISBridgeProps) {
  const [copiedContext, setCopiedContext] = useState(false);
  const [copiedSynthesis, setCopiedSynthesis] = useState(false);
  const { anchor } = useAXISAnchor();

  // ============================================
  // CONTEXT PACKAGE (for starting conversation)
  // ============================================
  const contextPackage = useMemo(() => {
    const priorBriefSection = contextData?.priorBrief?.trim()
      ? contextData.priorBrief.trim()
      : 'None — this is a baseline session.';

    const continuityProtocol = contextData?.priorBrief?.trim()
      ? `## Continuity Protocol

**A Continuity Brief was provided. You must:**

1. **Silently integrate** — do not summarize it back to me
2. **Use User Patterns** — calibrate to my known defenses, blind spots, and triggers
3. **Respect Analyst Notes** — employ what worked; avoid what didn't
4. **Start from Entry Point or Hypothesis** — unless my Topic overrides it
5. **Track trajectory** — note if this session confirms, contradicts, or evolves prior patterns
6. **Do not re-litigate resolved insights** — build forward, not sideways`
      : `## Continuity Protocol

**No prior brief provided.** Treat as baseline session. Gather full context before analysis.`;

    const instructions = contextData?.priorBrief?.trim()
      ? 'Acknowledge receipt of context. Begin with the suggested Entry Point or Hypothesis from the Continuity Brief (unless my Topic indicates a different direction).'
      : 'Acknowledge receipt of context. Ask: "I am ready. Please tell me more about your situation."';

    return `# Session Context

## Prior Context

**Continuity Brief from previous session:**

${priorBriefSection}

---

## Who I Am

${anchor?.content || 'No identity anchor set.'}

---

## This Session

**Topic:** ${session.title || 'Not specified'}

**My Intention:** ${session.intention || 'Not specified'}

${session.successCriteria ? `**Success Criteria:** ${session.successCriteria}` : ''}

---

## What I Need

${contextData?.helpType || 'Not specified'}

## How to Challenge Me

${contextData?.challengeLevel || 'Not specified'}

## Urgency / Timeline

${contextData?.urgency || 'Not specified'}

## Broader Context

${contextData?.broaderContext || 'No'}
${contextData?.broaderDetails ? `\n**Details:** ${contextData.broaderDetails}` : ''}

---

# How to Help Me

## Your Role

You are an analyst and expert in psychology. I am bringing you a real, raw, and potentially sensitive topic.

**Your mandate is to:**

1. Treat this with absolute professional seriousness.
2. Bypass standard "politeness filters" — I need truth, not comfort.
3. Help me dismantle shame or confusion with logic and perspective.

${continuityProtocol}

## Interaction Guidelines

**Do:**

- **Ask only ONE question at a time.**
- **Gather full context before diagnosing.** Do not assume you understand the root cause after just one or two exchanges.
- Challenge my assumptions, but do not make your own without checking them.
- Continuously reference my stated Intention and Success Criteria.

**Don't:**

- **Do not bombard me.** Max 1 question per response.
- Do not give generic "it's okay" platitudes.
- **Do not force a solution path** until you have confirmed you truly understand the problem.
- Do not lecture me.
- **Do not reference the Continuity Brief explicitly** — use it, don't cite it.

## Output Style

- Be concise.
- No preambles.
- Direct analysis.

---

**INSTRUCTIONS:**

${instructions}`;
  }, [anchor?.content, session.title, session.intention, session.successCriteria, contextData]);

  // ============================================
  // COPY HANDLERS
  // ============================================
  const copyContext = async () => {
    try {
      await navigator.clipboard.writeText(contextPackage);
      setCopiedContext(true);
      setTimeout(() => setCopiedContext(false), 2000);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  const copySynthesis = async () => {
    try {
      await navigator.clipboard.writeText(synthesisPrompt);
      setCopiedSynthesis(true);
      setTimeout(() => setCopiedSynthesis(false), 2000);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  // ============================================
  // RENDER
  // ============================================
  return (
    <div className="space-y-8 max-w-5xl mx-auto pt-4 animate-in fade-in duration-500">
      {/* Header */}
      <div className="pb-6 border-b border-purple-400/10 space-y-3">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-purple-300/70 hover:text-purple-300 transition-colors group"
        >
          <ChevronLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="text-sm font-medium">Back to Framing</span>
        </button>
        <h2 className="text-4xl font-serif text-neutral-50">Your Session Package</h2>
        <p className="text-neutral-300 text-base leading-relaxed">
          Two prompts to guide your AI conversation. Copy and use them in sequence.
        </p>
      </div>

      {/* Instructions Overview */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 space-y-4">
        <h3 className="text-lg font-semibold text-slate-100">How This Works</h3>
        <ol className="space-y-3 text-slate-300">
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-600 text-white text-sm flex items-center justify-center font-medium">1</span>
            <span><strong className="text-purple-300">Copy the Context Package</strong> (below) and paste it to start your AI conversation</span>
          </li>
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-600 text-white text-sm flex items-center justify-center font-medium">2</span>
            <span><strong className="text-purple-300">Have your conversation</strong> — take as long as you need</span>
          </li>
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-600 text-white text-sm flex items-center justify-center font-medium">3</span>
            <span><strong className="text-purple-300">When finished,</strong> copy the Synthesis Prompt (below) and paste it to generate a continuity brief</span>
          </li>
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-600 text-white text-sm flex items-center justify-center font-medium">4</span>
            <span><strong className="text-purple-300">Save the brief</strong> somewhere — you'll paste it next session to continue</span>
          </li>
        </ol>
      </div>

      {/* Prompts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Prompt 1: Context Package */}
        <div className="bg-purple-950/30 border border-purple-500/30 rounded-xl overflow-hidden flex flex-col">
          <div className="px-6 py-4 bg-purple-950/50 border-b border-purple-500/20 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MessageSquare size={20} className="text-purple-400" />
              <div>
                <h3 className="font-semibold text-purple-100">1. Context Package</h3>
                <p className="text-xs text-purple-300/70">START your conversation</p>
              </div>
            </div>
            <button
              onClick={copyContext}
              className="flex items-center gap-2 px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-medium transition-all"
            >
              {copiedContext ? <Check size={14} /> : <Copy size={14} />}
              {copiedContext ? 'Copied!' : 'Copy'}
            </button>
          </div>
          <pre className="p-4 overflow-auto text-xs text-slate-300 leading-relaxed font-mono flex-1 max-h-96">
            {contextPackage}
          </pre>
        </div>

        {/* Prompt 2: Synthesis Prompt */}
        <div className="bg-purple-950/30 border border-purple-500/30 rounded-xl overflow-hidden flex flex-col">
          <div className="px-6 py-4 bg-purple-950/50 border-b border-purple-500/20 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText size={20} className="text-purple-400" />
              <div>
                <h3 className="font-semibold text-purple-100">2. Synthesis Prompt</h3>
                <p className="text-xs text-purple-300/70">END your conversation</p>
              </div>
            </div>
            <button
              onClick={copySynthesis}
              className="flex items-center gap-2 px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-medium transition-all"
            >
              {copiedSynthesis ? <Check size={14} /> : <Copy size={14} />}
              {copiedSynthesis ? 'Copied!' : 'Copy'}
            </button>
          </div>
          <pre className="p-4 overflow-auto text-xs text-slate-300 leading-relaxed font-mono flex-1 max-h-96">
            {synthesisPrompt}
          </pre>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex justify-between pt-6 border-t border-slate-700">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 text-slate-400 hover:text-slate-200 transition-colors"
        >
          <ChevronLeft size={18} />
          Back
        </button>
        <button
          onClick={onComplete}
          className="px-6 py-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-serif font-medium transition-all"
        >
          I'm Ready → Go to Waiting Room
        </button>
      </div>
    </div>
  );
}

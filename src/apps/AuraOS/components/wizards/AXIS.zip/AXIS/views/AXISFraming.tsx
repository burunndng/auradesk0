/**
 * AXIS Framing - AI Conversation Prompt Generator
 * Create precise prompts for AI analysis conversations
 *
 * Design: Purple/Violet theme - Shadow Tools integration
 */

import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronDown } from 'lucide-react';
import SacredHexagon from '../../../icons/SacredHexagon';
import { StorageManager } from '../../../../.claude/lib/storageManager.ts';
import type { AXISSynthesisBrief } from '../../../../types';

const MAX_TOPIC_LENGTH = 100;
const MAX_PROMPT_LENGTH = 800;
const MAX_CONTEXT_LENGTH = 300;
const DRAFT_STORAGE_KEY = 'aura-AXIS-prompt-draft';

interface AXISFramingProps {
  onComplete: (title: string, intention: string, successCriteria?: string, activityType?: string, contextData?: any) => void;
  onBack: () => void;
  previousSynthesis?: AXISSynthesisBrief | null;
}

export default function AXISFraming({ onComplete, onBack, previousSynthesis }: AXISFramingProps) {
  const [topic, setTopic] = useState('');
  const [prompt, setPrompt] = useState('');
  const [context, setContext] = useState('');
  const [priorBrief, setPriorBrief] = useState('');

  // Context questions
  const [helpType, setHelpType] = useState('');
  const [challengeLevel, setChallengeLevel] = useState('');
  const [urgency, setUrgency] = useState('');
  const [broaderContext, setBroaderContext] = useState('');
  const [broaderDetails, setBroaderDetails] = useState('');

  // Load draft on mount
  useEffect(() => {
    let initialPriorBrief = '';

    if (previousSynthesis) {
      const { sessionFindings, userPatterns, nextSession } = previousSynthesis;
      initialPriorBrief = `Previous Session Key Insight:
${sessionFindings?.keyInsight || 'N/A'}

Patterns Identified:
- Core Dynamic: ${userPatterns?.coreDynamic || 'N/A'}
- Typical Defenses: ${userPatterns?.typicalDefenses || 'N/A'}

Next Session Focus:
${nextSession?.entryPoint ? `Entry: ${nextSession.entryPoint}` : ''}
${nextSession?.hypothesisToTest ? `Hypothesis: ${nextSession.hypothesisToTest}` : ''}`.trim();
    }

    const raw = StorageManager.getUntyped(DRAFT_STORAGE_KEY);
    if (raw) {
      try {
        const draft = raw as any;
        setTopic(draft.topic || '');
        setPrompt(draft.prompt || '');
        setContext(draft.context || '');
        setPriorBrief(draft.priorBrief || initialPriorBrief);
        setHelpType(draft.helpType || '');
        setChallengeLevel(draft.challengeLevel || '');
        setUrgency(draft.urgency || '');
        setBroaderContext(draft.broaderContext || '');
        setBroaderDetails(draft.broaderDetails || '');
      } catch (e) {
        console.error('[AXIS] Failed to load prompt draft:', e);
        if (initialPriorBrief) setPriorBrief(initialPriorBrief);
      }
    } else if (initialPriorBrief) {
      setPriorBrief(initialPriorBrief);
    }
  }, [previousSynthesis]);

  // Save draft on change
  useEffect(() => {
    if (topic || prompt || context || helpType || challengeLevel || urgency || broaderContext || priorBrief) {
      const draft = { topic, prompt, context, priorBrief, helpType, challengeLevel, urgency, broaderContext, broaderDetails };
      try {
        StorageManager.setUntyped(DRAFT_STORAGE_KEY, draft);
      } catch (e) {
        console.error('[AXIS] Failed to save prompt draft:', e);
      }
    }
  }, [topic, prompt, context, priorBrief, helpType, challengeLevel, urgency, broaderContext, broaderDetails]);

  const canContinue = topic.trim().length > 0 && prompt.trim().length > 0;

  const handleContinue = () => {
    if (canContinue) {
      StorageManager.delete(DRAFT_STORAGE_KEY);
      const contextData = {
        topic: topic.trim(),
        prompt: prompt.trim(),
        context: context.trim() || undefined,
        helpType,
        challengeLevel,
        urgency,
        broaderContext,
        broaderDetails,
        priorBrief: priorBrief.trim() || undefined
      };
      // Pass: title, intention, successCriteria, activityType, contextData
      onComplete(
        topic.trim(),
        prompt.trim(),
        context.trim() || undefined,
        'ai-conversation',  // AXIS is only for AI conversations now
        contextData
      );
    }
  };

  return (
    <div className="space-y-10 max-w-3xl">
      {/* Header */}
      <div className="space-y-6 pb-8 border-b border-purple-400/10 relative">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-purple-300/70 hover:text-purple-300 transition-colors duration-300 group"
        >
          <ChevronLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="text-sm font-medium">Back</span>
        </button>

        <div className="relative">
          <SacredHexagon className="absolute top-0 right-0 -translate-y-1 translate-x-2 opacity-80" />
          <h2 className="text-5xl font-serif text-neutral-50 mb-4 leading-tight">
            Generate AI Prompt
          </h2>
          <p className="text-neutral-300 text-base leading-relaxed max-w-2xl font-normal">
            Craft a precise prompt to guide AI analysis conversations. Clear framing enables deeper insights.
          </p>
        </div>
      </div>

      {/* Topic */}
      <div className="space-y-3">
        <div className="flex items-baseline gap-3">
          <span className="text-purple-400 font-serif text-2xl font-medium">I.</span>
          <label className="text-lg font-serif text-neutral-50 font-medium">What's the main topic?</label>
          <span className="text-xs text-neutral-500 ml-auto">{topic.length} / {MAX_TOPIC_LENGTH}</span>
        </div>
        <p className="text-xs text-neutral-400 font-normal">Brief subject for analysis</p>
        <input
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value.slice(0, MAX_TOPIC_LENGTH))}
          placeholder="e.g., Fear of commitment in relationships"
          className="w-full px-4 py-3.5 bg-neutral-900/40 border border-purple-400/20 rounded-xl text-neutral-50 placeholder-neutral-500 focus:border-purple-400/50 focus:ring-2 focus:ring-purple-400/20 outline-none transition-all duration-300 text-base font-normal"
        />
      </div>

      {/* Prompt */}
      <div className="space-y-3">
        <div className="flex items-baseline gap-3">
          <span className="text-purple-400 font-serif text-2xl font-medium">II.</span>
          <label className="text-lg font-serif text-neutral-50 font-medium">Write your prompt</label>
          <span className="text-xs text-neutral-500 ml-auto">{prompt.length} / {MAX_PROMPT_LENGTH}</span>
        </div>
        <p className="text-xs text-neutral-400 font-normal">
          Detailed instruction for the AI. Include what you want to explore, analyze, or understand.
        </p>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value.slice(0, MAX_PROMPT_LENGTH))}
          placeholder="e.g., Analyze the psychological roots of my fear of commitment. What patterns from childhood might be contributing? What beliefs am I holding that keep me stuck?"
          rows={6}
          className="w-full px-4 py-3.5 bg-neutral-900/40 border border-purple-400/20 rounded-xl text-neutral-50 placeholder-neutral-500 focus:border-purple-400/50 focus:ring-2 focus:ring-purple-400/20 outline-none transition-all duration-300 text-base font-normal resize-none"
        />
      </div>

      {/* Context (Optional) */}
      <div className="space-y-3">
        <div className="flex items-baseline gap-3">
          <span className="text-purple-300/60 font-serif text-2xl font-medium">III.</span>
          <label className="text-lg font-serif text-neutral-300 font-medium">Additional context (optional)</label>
          <span className="text-xs text-neutral-500 ml-auto">{context.length} / {MAX_CONTEXT_LENGTH}</span>
        </div>
        <p className="text-xs text-neutral-400 font-normal">
          Any background information that helps the AI understand your situation
        </p>
        <textarea
          value={context}
          onChange={(e) => setContext(e.target.value.slice(0, MAX_CONTEXT_LENGTH))}
          placeholder="e.g., I've been in multiple relationships that ended because I withdrew emotionally..."
          rows={3}
          className="w-full px-4 py-3.5 bg-neutral-900/30 border border-purple-400/10 rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-purple-400/40 focus:ring-2 focus:ring-purple-400/15 outline-none transition-all duration-300 text-base font-normal resize-none"
        />
      </div>

      {/* Context Questions Section */}
      <div className="border-t border-purple-400/10 pt-8 space-y-6">
        <div className="space-y-1">
          <h3 className="text-lg font-serif text-neutral-50 font-medium">How to Help You</h3>
          <p className="text-xs text-neutral-400">Optional details that refine how the AI responds (select or skip)</p>
        </div>

        {/* Help Type */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-neutral-300">What kind of help do you need?</label>
          <div className="grid grid-cols-2 gap-2">
            {['Analysis & clarity', 'Action planning', 'Validation & support', 'Devil\'s advocate'].map((option) => (
              <button
                key={option}
                onClick={() => setHelpType(helpType === option ? '' : option)}
                className={`text-left px-3 py-2 rounded-lg text-sm transition-all ${
                  helpType === option
                    ? 'bg-purple-600/40 border border-purple-400/60 text-purple-100'
                    : 'bg-purple-950/20 border border-purple-500/20 text-purple-300 hover:border-purple-400/40'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        {/* Challenge Level */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-neutral-300">How much challenge do you want?</label>
          <div className="grid grid-cols-2 gap-2">
            {['Gentle & supportive', 'Balanced', 'Push me hard', 'Socratic only'].map((option) => (
              <button
                key={option}
                onClick={() => setChallengeLevel(challengeLevel === option ? '' : option)}
                className={`text-left px-3 py-2 rounded-lg text-sm transition-all ${
                  challengeLevel === option
                    ? 'bg-purple-600/40 border border-purple-400/60 text-purple-100'
                    : 'bg-purple-950/20 border border-purple-500/20 text-purple-300 hover:border-purple-400/40'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        {/* Urgency */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-neutral-300">How urgent is this?</label>
          <div className="grid grid-cols-2 gap-2">
            {['Long-term exploration', 'Moderate timeline', 'This week', 'Today'].map((option) => (
              <button
                key={option}
                onClick={() => setUrgency(urgency === option ? '' : option)}
                className={`text-left px-3 py-2 rounded-lg text-sm transition-all ${
                  urgency === option
                    ? 'bg-purple-600/40 border border-purple-400/60 text-purple-100'
                    : 'bg-purple-950/20 border border-purple-500/20 text-purple-300 hover:border-purple-400/40'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        {/* Broader Context */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-neutral-300">What's the broader context?</label>
          <div className="space-y-2">
            {[
              { value: 'childhood', label: 'Rooted in childhood patterns' },
              { value: 'recurring', label: 'Recurring pattern across life' },
              { value: 'health', label: 'Health, neuro, or substance factors' },
              { value: 'recent-event', label: 'Recent life event' },
              { value: 'spiritual', label: 'Spiritual or existential layer' },
              { value: 'nothing', label: 'Nothing in particular' }
            ].map((option) => (
              <button
                key={option.value}
                onClick={() => setBroaderContext(broaderContext === option.value ? '' : option.value)}
                className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-all ${
                  broaderContext === option.value
                    ? 'bg-purple-600/40 border border-purple-400/60 text-purple-100'
                    : 'bg-purple-950/20 border border-purple-500/20 text-purple-300 hover:border-purple-400/40'
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        {/* Broader Details - Conditional Input */}
        {broaderContext && broaderContext !== 'nothing' && (
          <div className="space-y-2 animate-in fade-in duration-300">
            <label className="text-sm font-medium text-neutral-300">Tell me more:</label>
            <textarea
              value={broaderDetails}
              onChange={(e) => setBroaderDetails(e.target.value)}
              placeholder="Add any relevant details..."
              rows={3}
              className="w-full px-3 py-2 bg-neutral-900/30 border border-purple-400/10 rounded-lg text-neutral-100 placeholder-neutral-500 focus:border-purple-400/40 focus:ring-2 focus:ring-purple-400/15 outline-none transition-all duration-300 text-sm font-normal resize-none"
            />
          </div>
        )}
      </div>

      {/* Prior Continuity Brief - Optional */}
      <div className="space-y-3">
        <label className="text-lg font-serif text-neutral-50 font-medium">
          Continuing a Previous Session?
          <span className="text-xs text-neutral-400 font-normal ml-2">(optional)</span>
        </label>
        <p className="text-xs text-neutral-400 font-normal">
          If you have a continuity brief from a previous AXIS conversation, paste it here.
        </p>
        <textarea
          value={priorBrief}
          onChange={(e) => setPriorBrief(e.target.value)}
          placeholder="Paste your prior continuity brief here, or leave blank for a fresh session..."
          rows={4}
          className="w-full px-4 py-3.5 bg-neutral-900/30 border border-purple-400/10 rounded-xl text-neutral-100 placeholder-neutral-500 focus:border-purple-400/40 focus:ring-2 focus:ring-purple-400/15 outline-none transition-all duration-300 text-base font-normal resize-none"
        />
      </div>

      {/* Continue Button */}
      <div className="pt-6">
        <button
          onClick={handleContinue}
          disabled={!canContinue}
          className={`
            w-full px-6 py-4 rounded-xl font-serif text-lg transition-all transform
            ${canContinue
              ? 'bg-gradient-to-r from-purple-600 to-purple-500 text-purple-50 hover:from-purple-500 hover:to-purple-400 shadow-lg shadow-purple-900/30 hover:shadow-xl hover:shadow-purple-900/40 hover:scale-[1.02] active:scale-[0.99]'
              : 'bg-slate-800 text-slate-600 cursor-not-allowed opacity-50'
            }
          `}
        >
          {canContinue ? 'Continue to Bridge →' : 'Complete required fields above'}
        </button>
      </div>
    </div>
  );
}

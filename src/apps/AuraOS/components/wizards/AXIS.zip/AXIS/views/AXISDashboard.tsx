/**
 * AXIS Dashboard
 * Entry point with identity anchor and activity selection
 */

import React, { useState, useRef } from 'react';
import { ChevronRight, Edit2, Download, Upload } from 'lucide-react';
import type { AXISAnchor, AXISActivityType, AXISSynthesisBrief } from '../../../../types';
import AXISAnchorEditor from '../components/AXISAnchorEditor';
import AXISActivityPicker from '../components/AXISActivityPicker';
import { exportAllData, importAllData, downloadExportJSON, type AXISExportData } from '../../../../services/AXISStorage';
import type { AXISAnchorMode } from '../../../../types';

interface AXISDashboardProps {
  anchor: AXISAnchor | null;
  hasAnchor: boolean;
  sessionCount: number;
  openSessionCount: number;
  previousSynthesis?: AXISSynthesisBrief | null;
  onStartFraming: () => void;
  onStartNative?: () => void;
  onStartOffAxis?: () => void;
  onViewHistory: () => void;
  onCreateAnchor: (content: string, mode?: AXISAnchorMode) => void;
  onEditAnchor: (content: string, mode?: AXISAnchorMode) => void;
  onDataImported?: () => void;
}

export default function AXISDashboard({
  anchor,
  hasAnchor,
  sessionCount,
  openSessionCount,
  previousSynthesis,
  onStartFraming,
  onStartNative,
  onStartOffAxis,
  onViewHistory,
  onCreateAnchor,
  onEditAnchor,
  onDataImported,
}: AXISDashboardProps) {
  const [isEditingAnchor, setIsEditingAnchor] = useState(!hasAnchor);
  const [selectedActivity, setSelectedActivity] = useState<AXISActivityType | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExport = async () => {
    const data = await exportAllData();
    downloadExportJSON(data);
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setImportError(null);
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text) as AXISExportData;
      await importAllData(data);
      onDataImported?.();
    } catch (err) {
      setImportError('Invalid export file. Please use a valid AXIS export.');
    }
    // Reset file input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleActivitySelect = (activity: AXISActivityType) => {
    setSelectedActivity(activity);
    onStartFraming();
  };

  if (isEditingAnchor && !hasAnchor) {
    return (
      <AXISAnchorEditor
        onSave={(content, mode) => {
          onCreateAnchor(content, mode);
          setIsEditingAnchor(false);
        }}
        isCreating={true}
      />
    );
  }

  return (
    <div className="space-y-8 max-w-2xl">
      {/* Header with meta-practice description */}
      <div className="text-center">
        <p className="text-xs text-slate-400 leading-relaxed">
          A longitudinal practice container — integrates Mind, Shadow, and Spirit dimensions across your sessions.
        </p>
      </div>

      {/* Your Anchor */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-amber-200 uppercase tracking-wider">Your Anchor</h3>
          {hasAnchor && (
            <button
              onClick={() => setIsEditingAnchor(true)}
              className="p-1 hover:bg-slate-800 rounded transition-colors text-slate-400 hover:text-slate-300"
            >
              <Edit2 size={16} />
            </button>
          )}
        </div>

        {isEditingAnchor ? (
          <AXISAnchorEditor
            initialValue={anchor?.content}
            initialMode={anchor?.mode}
            onSave={(content, mode) => {
              onEditAnchor(content, mode);
              setIsEditingAnchor(false);
            }}
            isCreating={false}
          />
        ) : (
          <div className="bg-slate-900/50 border border-slate-700 rounded-lg p-4">
            <p className="text-slate-300 leading-relaxed mb-3">{anchor?.content}</p>
            {anchor?.updatedAt && (
              <p className="text-xs text-slate-500">
                Last updated: {new Date(anchor.updatedAt).toLocaleDateString()}
              </p>
            )}
          </div>
        )}
      </div>

      {/* Action Edge Check-in — surfaces prior hypothesis before new session */}
      {previousSynthesis?.nextSession?.hypothesisToTest && (
        <div className="rounded-lg border border-amber-700/40 bg-amber-950/20 px-4 py-3">
          <p className="text-xs uppercase tracking-widest text-amber-500 mb-1">From last session</p>
          <p className="text-amber-200/90 text-sm italic">"{previousSynthesis.nextSession.hypothesisToTest}"</p>
          <p className="text-amber-400/60 text-xs mt-1.5">Did you get a chance to explore this?</p>
        </div>
      )}

      {/* Divider */}
      <div className="border-t border-slate-700" />

      {/* Activity Selection */}
      <div>
        <h3 className="text-sm font-semibold text-amber-200 mb-4 uppercase tracking-wider">
          What Are You About to Do?
        </h3>
        <AXISActivityPicker onSelect={handleActivitySelect} />
      </div>

      {/* Help Text */}
      <div className="bg-slate-900/30 border border-slate-800 rounded-lg p-4">
        <p className="text-sm text-slate-400 leading-relaxed">
          AXIS bookends any reflective experience with intention before and meaning capture after.
          Frame your session, do your thing, and return to harvest what mattered.
        </p>
      </div>

      {/* Off-Axis (Side Quest) */}
      {onStartOffAxis && hasAnchor && (
        <div className="rounded-lg border border-slate-700/50 bg-slate-900/30 px-4 py-3">
          <p className="text-xs text-slate-500 mb-2 uppercase tracking-wider">Side Quest</p>
          <p className="text-xs text-slate-400 mb-3 leading-relaxed">
            Need to work through something unrelated to your anchor? Start an off-axis session — it won't affect your main synthesis chain.
          </p>
          <button
            onClick={onStartOffAxis}
            className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 bg-slate-800/50 hover:bg-slate-800 rounded border border-slate-700 hover:border-slate-600 transition-colors"
          >
            Start Off-Axis Session
          </button>
        </div>
      )}

      {/* History Section */}
      {sessionCount > 0 && (
        <>
          <div className="border-t border-slate-700" />
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-amber-200 mb-2 uppercase tracking-wider">
                Sessions
              </h3>
              <p className="text-xs text-slate-500">
                {sessionCount} total {openSessionCount > 0 && `• ${openSessionCount} open`}
              </p>
            </div>
            <button
              onClick={onViewHistory}
              className="px-4 py-2 text-sm bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors"
            >
              View History
            </button>
          </div>
        </>
      )}

      {/* Data Export / Import */}
      <div className="border-t border-slate-700 pt-4">
        <div className="flex gap-2 items-center">
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 bg-slate-800/50 hover:bg-slate-800 rounded transition-colors"
          >
            <Download size={12} />
            Export data
          </button>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 bg-slate-800/50 hover:bg-slate-800 rounded transition-colors"
          >
            <Upload size={12} />
            Import
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            className="hidden"
            onChange={handleImportFile}
          />
        </div>
        {importError && (
          <p className="text-xs text-red-400 mt-1">{importError}</p>
        )}
      </div>
    </div>
  );
}

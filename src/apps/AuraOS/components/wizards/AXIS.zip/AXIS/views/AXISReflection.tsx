/**
 * AXIS Reflection
 * Capture what stood out, what changed, what remains open
 */

import React, { useState, useEffect } from 'react';
import type { AXISSession, AXISReflection, AXISAnchorMode } from '../../../../types';
import { StorageManager } from '../../../../.claude/lib/storageManager.ts';

const MAX_REFLECTION_LENGTH = 2000;
const DRAFT_STORAGE_PREFIX = 'aura-AXIS-reflection-draft-';

const MODE_PROMPTS: Record<AXISAnchorMode | 'default', { salience: string; delta: string; residue: string }> = {
  'emotional-pattern': {
    salience: 'What felt most true in what came up today?',
    delta: 'Did anything shift in how you understand a recurring feeling or pattern?',
    residue: 'What emotional thread is still alive and unresolved?',
  },
  'behavioral-change': {
    salience: "What's one concrete thing you noticed or decided?",
    delta: "What shifted in how you think about a behavior you're working on?",
    residue: 'What will you try or observe before next session?',
  },
  'identity-transition': {
    salience: "How does what we explored today sit with the version of yourself you're moving toward?",
    delta: "Did your sense of who you are or who you're becoming shift at all?",
    residue: 'What questions about your identity or direction remain open?',
  },
  'relational': {
    salience: 'What did you notice about your own patterns in what we discussed?',
    delta: 'Did anything shift in how you see a relationship or relational dynamic?',
    residue: 'What relational thread feels unresolved or still needs attention?',
  },

  default: {
    salience: 'What stood out? What surprised you or felt important?',
    delta: 'How has your understanding or perspective shifted?',
    residue: 'What questions or threads are still alive?',
  },
};

interface AXISReflectionProps {
  session: AXISSession;
  anchorMode?: AXISAnchorMode;
  onComplete: (reflection: AXISReflection) => void;
  onBack: () => void;
}

export default function AXISReflection({ session, anchorMode, onComplete, onBack }: AXISReflectionProps) {
  const [salience, setSalience] = useState('');
  const [delta, setDelta] = useState('');
  const [residue, setResidue] = useState('');
  const [selfNoticing, setSelfNoticing] = useState('');
  const draftKey = `${DRAFT_STORAGE_PREFIX}${session.id}`;
  const prompts = MODE_PROMPTS[anchorMode ?? 'default'];

  // Load draft on mount
  useEffect(() => {
    const raw = StorageManager.getUntyped(draftKey);
    if (raw) {
      try {
        const draft = raw as any;
        setSalience(draft.salience);
        setDelta(draft.delta);
        setResidue(draft.residue);
        setSelfNoticing(draft.selfNoticing || '');
      } catch (e) {
        console.error('[AXIS] Failed to load reflection draft:', e);
      }
    }
  }, [draftKey]);

  // Save draft on change
  useEffect(() => {
    const draft = { salience, delta, residue, selfNoticing };
    try {
      StorageManager.setUntyped(draftKey, draft);
    } catch (e) {
      console.error('[AXIS] Failed to save reflection draft:', e);
    }
  }, [salience, delta, residue, selfNoticing, draftKey]);

  const canContinue = salience.trim().length > 0;

  const handleContinue = () => {
    if (canContinue) {
      // Clear draft on success
      StorageManager.delete(draftKey);
      onComplete({
        salience: salience.trim(),
        delta: delta.trim() || undefined,
        residue: residue.trim() || undefined,
        selfNoticing: selfNoticing.trim() || undefined,
      });
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-serif text-amber-50 mb-1">{session.title}</h2>
        <p className="text-slate-400 text-sm">Capture what mattered</p>
      </div>

      {/* What stood out */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="block text-sm font-semibold text-amber-200 uppercase tracking-wider">
            Reflection *
          </label>
          <span className="text-xs text-slate-500">{salience.length} / {MAX_REFLECTION_LENGTH}</span>
        </div>
        <textarea
          value={salience}
          onChange={(e) => setSalience(e.target.value.slice(0, MAX_REFLECTION_LENGTH))}
          placeholder={prompts.salience}
          rows={4}
          className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-600 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-colors resize-none"
        />
      </div>

      {/* What changed */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="block text-sm font-semibold text-amber-200 uppercase tracking-wider">
            What changed, if anything?
          </label>
          <span className="text-xs text-slate-500">{delta.length} / {MAX_REFLECTION_LENGTH}</span>
        </div>
        <textarea
          value={delta}
          onChange={(e) => setDelta(e.target.value.slice(0, MAX_REFLECTION_LENGTH))}
          placeholder={prompts.delta}
          rows={3}
          className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-600 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-colors resize-none"
        />
      </div>

      {/* What remains open */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="block text-sm font-semibold text-amber-200 uppercase tracking-wider">
            What remains open?
          </label>
          <span className="text-xs text-slate-500">{residue.length} / {MAX_REFLECTION_LENGTH}</span>
        </div>
        <textarea
          value={residue}
          onChange={(e) => setResidue(e.target.value.slice(0, MAX_REFLECTION_LENGTH))}
          placeholder={prompts.residue}
          rows={3}
          className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-600 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-colors resize-none"
        />
      </div>

      {/* Self-noticing (obsolescence scaffolding) */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="block text-sm font-semibold text-amber-200 uppercase tracking-wider">
            Self-noticing (optional)
          </label>
          <span className="text-xs text-slate-500">{selfNoticing.length} / {MAX_REFLECTION_LENGTH}</span>
        </div>
        <textarea
          value={selfNoticing}
          onChange={(e) => setSelfNoticing(e.target.value.slice(0, MAX_REFLECTION_LENGTH))}
          placeholder="What are you now noticing on your own that AXIS used to surface for you?"
          rows={3}
          className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-600 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-colors resize-none"
        />
      </div>

      {/* Buttons */}
      <div className="space-y-2">
        <button
          onClick={handleContinue}
          disabled={!canContinue}
          className="w-full px-4 py-3 bg-amber-600 text-amber-50 rounded-lg hover:bg-amber-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
        >
          Save Reflection
        </button>
        <button
          onClick={onBack}
          className="w-full px-4 py-3 bg-slate-800 text-slate-100 rounded-lg hover:bg-slate-700 transition-colors font-medium"
        >
          Back
        </button>
      </div>
    </div>
  );
}

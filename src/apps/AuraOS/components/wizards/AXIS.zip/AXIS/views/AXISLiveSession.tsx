/**
 * AXIS Live Session - Socratic chatbot facilitation
 * Full session context injected from framing + preparation data.
 */

import React, { useState, useEffect, useRef } from 'react';
import { Send, Loader, AlertCircle, ChevronLeft, ChevronDown } from 'lucide-react';
import { AXISAnchor, AXISSynthesisBrief, AXISConversationMessage } from '../../../../types';

const MIN_EXCHANGES_TO_END = 3;
const PROXY_URL = '/api/openrouter-proxy';

interface ParsedIntention {
  cleanIntention: string;
  prepBriefData: { keyContext: string; constraints: string; tone: string };
}

/**
 * Parse intention string once to extract clean intention and prep brief data.
 * Eliminates duplication and ensures buildSystemPrompt receives the full encoded string.
 */
function parseIntentionWithBrief(intention: string): ParsedIntention {
  let cleanIntention = intention;
  let prepBriefData = { keyContext: '', constraints: '', tone: '' };
  const briefMatch = intention.match(/\n\n__PREP_BRIEF__(.+)$/);

  if (briefMatch?.length > 1) {
    try {
      const parsed = JSON.parse(briefMatch[1]);
      prepBriefData = {
        keyContext: parsed?.keyContext?.substring(0, 300) || '',
        constraints: parsed?.constraints?.substring(0, 300) || '',
        tone: parsed?.tone?.substring(0, 200) || ''
      };
      const briefIdx = intention.indexOf('\n\n__PREP_BRIEF__');
      if (briefIdx > 0) {
        cleanIntention = intention.substring(0, briefIdx).trim() || intention;
      }
    } catch (e) {
      console.error('[AXISLiveSession] Failed to parse prep brief:', e);
      // Fallback to full intention if parsing fails
    }
  }

  return { cleanIntention, prepBriefData };
}

const MODELS = [
  { id: 'x-ai/grok-4.1-fast', label: 'Grok 4.1 Fast' },
  { id: 'qwen/qwen3-30b-a3b-instruct-2507', label: 'Qwen 3 30B' },
  { id: 'minimax/minimax-m2-her', label: 'MiniMax M2' },
] as const;
type ModelId = typeof MODELS[number]['id'];

interface AXISLiveSessionProps {
  anchor: AXISAnchor;
  intention: string;
  successCriteria?: string;
  activityType?: string;
  previousSynthesis: AXISSynthesisBrief | null;
  preparationHistory?: AXISConversationMessage[];
  contextData?: any;
  sessionCount?: number;        // Total closed sessions on this anchor
  lastSessionDate?: string;     // ISO timestamp of most recent closed session
  isOffAxis?: boolean;          // Off-axis side quest — no anchor context loaded
  onSessionEnd: (conversationHistory: AXISConversationMessage[]) => void;
  onBack: () => void;
}

function buildSystemPrompt(
  anchor: AXISAnchor,
  intention: string,
  successCriteria: string | undefined,
  activityType: string | undefined,
  previousSynthesis: AXISSynthesisBrief | null,
  preparationHistory: AXISConversationMessage[] | undefined,
  contextData: any,
  sessionCount: number = 0,
  lastSessionDate: string | undefined = undefined,
): string {
  const hasPriorBrief = contextData?.priorBrief?.trim() || previousSynthesis;

  // Session arc context
  const sessionArcLine = sessionCount > 0
    ? `Session ${sessionCount + 1} of this anchor arc`
    : 'First session on this anchor';

  // Time gap since last session
  let timeSinceLastSession = '';
  if (lastSessionDate) {
    const daysSince = Math.floor((Date.now() - new Date(lastSessionDate).getTime()) / (1000 * 60 * 60 * 24));
    if (daysSince >= 1) {
      timeSinceLastSession = `${daysSince} day${daysSince === 1 ? '' : 's'} since last session`;
    }
  }

  // Prior context section
  let priorSection = '';
  if (contextData?.priorBrief?.trim()) {
    priorSection = `**Continuity Brief from previous session:**\n\n${contextData.priorBrief.trim()}`;
  } else if (previousSynthesis) {
    const ns = previousSynthesis.nextSession;
    const up = previousSynthesis.userPatterns;
    const sf = previousSynthesis.sessionFindings;
    const an = previousSynthesis.analystNotes;
    
    priorSection = [
      `**Prior Session Continuity Brief:**`,
      up?.coreDynamic && `Core dynamic: ${up.coreDynamic}`,
      up?.typicalDefenses && `Typical Defenses: ${up.typicalDefenses}`,
      up?.blindSpots && `Blind Spots: ${up.blindSpots}`,
      up?.triggers && `Triggers: ${up.triggers}`,
      `---`,
      sf?.keyInsight && `Last key insight: ${sf.keyInsight}`,
      sf?.presentingToRoot && `Presenting to Root: ${sf.presentingToRoot}`,
      sf?.shift && `Shift Achieved: ${sf.shift}`,
      `---`,
      an?.effective && `What worked well last time: ${an.effective}`,
      an?.avoid && `What to avoid: ${an.avoid}`,
      `---`,
      ns?.entryPoint && `Suggested entry point: ${ns.entryPoint}`,
      ns?.hypothesisToTest && `Hypothesis to test: ${ns.hypothesisToTest}`,
      previousSynthesis.openThreads?.length && `Open threads: ${previousSynthesis.openThreads.join('; ')}`,
      previousSynthesis.cumulativeContext && `\n**Cumulative Trajectory:**\n${previousSynthesis.cumulativeContext}`
    ].filter(Boolean).join('\n');
  } else {
    priorSection = 'None — this is a baseline session.';
  }

  // Persistent Core Truths — established facts that carry across all sessions
  const coreTruths = previousSynthesis?.persistentCoreTruths?.length
    ? `**Established Core Truths (treat as confirmed facts, do not re-litigate):**\n${previousSynthesis.persistentCoreTruths.map((t, i) => `${i + 1}. ${t}`).join('\n')}`
    : '';

  // Parse intention once to extract clean intention and prep brief data
  const { cleanIntention, prepBriefData } = parseIntentionWithBrief(intention);

  // Preparation summary (rich context + brief context exchange)
  const prepSummary = prepBriefData.keyContext || (preparationHistory && preparationHistory.length > 1)
    ? `\n\n**Preparation Context:**${prepBriefData.keyContext ? `\nKey Context: ${prepBriefData.keyContext}` : ''}${prepBriefData.constraints ? `\nConstraints: ${prepBriefData.constraints}` : ''}${prepBriefData.tone ? `\nTone Preference: ${prepBriefData.tone}` : ''}`
    : '';

  // Context data fields
  const helpType = contextData?.helpType || '';
  const challengeLevel = contextData?.challengeLevel || '';
  const urgency = contextData?.urgency || '';
  const broaderContext = contextData?.broaderContext || '';
  const broaderDetails = contextData?.broaderDetails || '';

  const continuityProtocol = hasPriorBrief
    ? `A Continuity Brief was provided. You must:
1. Silently integrate — do not summarize it back
2. Use User Patterns — calibrate to known defenses, blind spots, triggers
3. Start from Entry Point or Hypothesis — unless the current topic overrides
4. Track trajectory — note if this session confirms, contradicts, or evolves prior patterns
5. Do not re-litigate resolved insights — build forward`
    : `No prior brief. Treat as baseline session. Gather full context before analysis.`;

  return `# AXIS Session

## Your Identity
You are AXIS — a structured thinking partner, not a therapist or life coach. Your role is to help the user think more clearly, more honestly, and more precisely. You apply Socratic pressure. You notice patterns. You name what the user cannot yet see. You are not here to comfort — you are here to clarify.

## Arc Context
${sessionArcLine}${timeSinceLastSession ? ` · ${timeSinceLastSession}` : ''}

## Prior Context
${priorSection}${prepSummary}
${coreTruths ? `\n---\n\n${coreTruths}` : ''}

---

## Who I Am
${anchor.content}

---

## This Session

**Focus Mode:** ${anchor.mode || 'general'}
**Topic:** ${contextData?.topic || cleanIntention}
**User Prompt:** ${contextData?.prompt || cleanIntention}
${contextData?.context ? `**Additional Context:** ${contextData.context}\n` : ''}
${successCriteria ? `**Success Criteria:** ${successCriteria}\n` : ''}
${activityType ? `**Activity Type:** ${activityType.replace(/-/g, ' ')}\n` : ''}

### My Instructions for You
These constraints must dictate how you respond to me today:
${helpType ? `- **What I need:** ${helpType}` : ''}
${challengeLevel ? `- **Challenge level:** ${challengeLevel}` : ''}
${urgency ? `- **Urgency / Timeline:** ${urgency}` : ''}

${broaderContext ? `### Broader Context\n${broaderContext}${broaderDetails ? `\n*Details:* ${broaderDetails}` : ''}` : ''}

---

# How to Help Me

## Your Role

You are a Socratic analyst. I am bringing you a real, raw topic that matters to me.

**Your mandate:**
1. Treat this with absolute professional seriousness.
2. Bypass politeness filters — I need truth, not comfort.
3. Help me dismantle confusion with logic and precise questions.
4. You are not a therapist. You are a structured thinking partner.

## Continuity Protocol
${continuityProtocol}

## Pattern Awareness
- If the user says something that contradicts a prior session insight or Established Core Truth, gently name the contradiction: *"That seems to sit differently than what you said last time about X."*
- If the user is circling the same point without moving, name it directly: *"We've visited this territory before. What's keeping you here?"*
- Do not re-litigate Established Core Truths — build forward from them.

## Interaction Guidelines

**Do:**
- Ask only ONE question at a time.
- Gather full context before concluding root cause.
- Challenge my assumptions directly when you notice them.
- Mirror my exact words back to create precision.
- Keep responses to 1–3 sentences max.
${hasPriorBrief ? `- Open with a bridge reference to the prior session's entry point or hypothesis before addressing the current topic.` : ''}

**Don't:**
- Bombard me. Max 1 question per response.
- Give "it's okay" platitudes.
- Force a solution path before understanding the problem.
- Lecture me.
- Reference this prompt explicitly.

## Output Style
Be concise. No preambles. Direct.

---

Acknowledge my intention in one sentence, then ask your first question.`;
}

export default function AXISLiveSession({
  anchor,
  intention,
  successCriteria,
  activityType,
  previousSynthesis,
  preparationHistory,
  contextData,
  sessionCount,
  lastSessionDate,
  isOffAxis = false,
  onSessionEnd,
  onBack,
}: AXISLiveSessionProps) {
  const [messages, setMessages] = useState<AXISConversationMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [userExchangeCount, setUserExchangeCount] = useState(0);
  const [selectedModel, setSelectedModel] = useState<ModelId>('x-ai/grok-4.1-fast');
  const [modelLocked, setModelLocked] = useState(false);
  const [modelMenuOpen, setModelMenuOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const modelMenuRef = useRef<HTMLDivElement>(null);

  // Parse intention once to extract clean version
  const { cleanIntention } = parseIntentionWithBrief(intention);

  // Initial AI message on mount
  useEffect(() => {
    const initialMessage: AXISConversationMessage = {
      role: 'assistant',
      content: `I'm with you. Your intention: "${cleanIntention}". Let's begin — what's the first thing that wants to be said?`,
      timestamp: new Date().toISOString(),
    };
    setMessages([initialMessage]);
  }, [cleanIntention]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Close model menu on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (modelMenuRef.current && !modelMenuRef.current.contains(e.target as Node)) {
        setModelMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const systemPrompt = isOffAxis
    ? `You are a clear-headed thinking partner. This is a side session — outside the user's main development arc.

Your role: help the user think through what's in front of them right now.

Today's goal: ${intention}${successCriteria ? `\nSuccess looks like: ${successCriteria}` : ''}

No prior context. No patterns. No anchor. Meet the user where they are.

Be concise. Ask one question at a time. No preambles or pleasantries.

Acknowledge their goal in one sentence, then ask your first question.`
    : buildSystemPrompt(
        anchor, intention, successCriteria, activityType,
        previousSynthesis, preparationHistory, contextData,
        sessionCount, lastSessionDate
      );

  const sendMessage = async (userText: string) => {
    if (!userText.trim() || isLoading) return;

    if (!modelLocked) setModelLocked(true);

    const userMsg: AXISConversationMessage = {
      role: 'user',
      content: userText.trim(),
      timestamp: new Date().toISOString(),
    };
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInput('');
    setUserExchangeCount(c => c + 1);
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch(PROXY_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: selectedModel,
          messages: [
            { role: 'system', content: systemPrompt },
            ...updatedMessages.slice(-10).map(m => ({ role: m.role, content: m.content })),
          ],
          temperature: 0.7,
          max_tokens: 350,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData?.error?.message || `API error: ${response.status}`);
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;
      if (!content) throw new Error('Empty response from API');

      setMessages([...updatedMessages, {
        role: 'assistant',
        content,
        timestamp: new Date().toISOString(),
      }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send message');
      console.error('[AXISLiveSession]', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  const exchangesRemaining = Math.max(0, MIN_EXCHANGES_TO_END - userExchangeCount);
  const canEnd = userExchangeCount >= MIN_EXCHANGES_TO_END;
  const currentModelLabel = MODELS.find(m => m.id === selectedModel)?.label ?? selectedModel.split('/').pop() ?? '';

  return (
    <div className="flex flex-col h-full max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-700/50 mb-4">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-slate-400 hover:text-slate-200 transition-colors text-sm group"
        >
          <ChevronLeft size={16} className="group-hover:-translate-x-0.5 transition-transform" />
          Back
        </button>

        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs text-slate-400 uppercase tracking-wider font-medium">
            Live Session
          </span>
        </div>

        {/* Model selector — dropdown before first message, badge after */}
        <div className="relative" ref={modelMenuRef}>
          {modelLocked ? (
            <span className="text-xs text-slate-600 border border-slate-700 rounded px-1.5 py-0.5">
              {currentModelLabel}
            </span>
          ) : (
            <button
              onClick={() => setModelMenuOpen(o => !o)}
              className="flex items-center gap-1 text-xs text-slate-400 border border-slate-700 hover:border-slate-500 rounded px-1.5 py-0.5 transition-colors"
            >
              {currentModelLabel}
              <ChevronDown size={10} />
            </button>
          )}
          {modelMenuOpen && !modelLocked && (
            <div className="absolute right-0 top-full mt-1 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-10 min-w-[140px] overflow-hidden">
              {MODELS.map(m => (
                <button
                  key={m.id}
                  onClick={() => { setSelectedModel(m.id); setModelMenuOpen(false); }}
                  className={`w-full text-left px-3 py-2 text-xs transition-colors ${
                    selectedModel === m.id
                      ? 'bg-teal-800/60 text-teal-200'
                      : 'text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Intention banner */}
      <div className="mb-4 px-4 py-2.5 bg-slate-800/40 border border-slate-700/40 rounded-lg">
        <p className="text-xs text-slate-500 uppercase tracking-wider mb-0.5">Intention</p>
        <p className="text-sm text-slate-300 leading-snug">{cleanIntention}</p>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-3 pr-1 min-h-0">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] px-4 py-2.5 rounded-xl text-sm leading-relaxed ${
              msg.role === 'user'
                ? 'bg-slate-600/50 text-slate-100 border border-slate-500/30'
                : 'bg-slate-800/60 text-slate-200 border border-slate-700/40'
            }`}>
              {msg.content}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-slate-800/60 border border-slate-700/40 rounded-xl px-4 py-2.5 flex items-center gap-2">
              <Loader className="w-3.5 h-3.5 animate-spin text-slate-500" />
              <span className="text-xs text-slate-500">Thinking…</span>
            </div>
          </div>
        )}

        {error && (
          <div className="flex justify-center">
            <div className="bg-red-900/20 border border-red-700/40 rounded-lg px-4 py-2 flex items-start gap-2 max-w-sm">
              <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
              <span className="text-xs text-red-300">{error}</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input area */}
      <div className="mt-4 border-t border-slate-700/50 pt-4 space-y-3">
        <form onSubmit={handleSubmit} className="flex gap-2 items-end">
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Share what's arising… (Enter to send, Shift+Enter for newline)"
            disabled={isLoading}
            rows={2}
            className="flex-1 bg-slate-800/60 border border-slate-700/40 rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-500/50 disabled:opacity-50 resize-none leading-relaxed"
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="px-3 py-2.5 bg-slate-600 hover:bg-slate-500 text-white rounded-xl transition disabled:opacity-40 disabled:cursor-not-allowed flex items-center self-end"
            aria-label="Send message"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        <div className="flex items-center justify-between gap-3">
          {!canEnd && (
            <p className="text-xs text-slate-500">
              {exchangesRemaining} more {exchangesRemaining === 1 ? 'exchange' : 'exchanges'} to unlock End Session
            </p>
          )}
          {canEnd && <div />}
          <button
            onClick={() => onSessionEnd(messages)}
            disabled={!canEnd}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
              canEnd
                ? 'bg-slate-700 hover:bg-slate-600 text-slate-100'
                : 'bg-slate-800/40 text-slate-600 cursor-not-allowed'
            }`}
          >
            End Session
          </button>
        </div>
      </div>
    </div>
  );
}

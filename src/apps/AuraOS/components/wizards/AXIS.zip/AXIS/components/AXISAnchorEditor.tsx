/**
 * AXIS Anchor Editor
 * Create or edit identity anchor with optional mode selection
 */

import React, { useState } from 'react';
import type { AXISAnchorMode } from '../../../../types';

const MAX_ANCHOR_LENGTH = 500;

const ANCHOR_MODES: { value: AXISAnchorMode; label: string; description: string }[] = [
  {
    value: 'emotional-pattern',
    label: 'Emotional Pattern',
    description: 'Exploring recurring feelings, defenses, and inner dynamics',
  },
  {
    value: 'behavioral-change',
    label: 'Behavioral Change',
    description: 'Tracking habits, action edges, and concrete shifts',
  },
  {
    value: 'identity-transition',
    label: 'Identity Transition',
    description: 'Navigating a role change, life chapter, or self-concept shift',
  },
  {
    value: 'relational',
    label: 'Relational',
    description: 'Working through patterns in relationships and connection',
  },
];

interface AXISAnchorEditorProps {
  initialValue?: string;
  initialMode?: AXISAnchorMode;
  onSave: (content: string, mode?: AXISAnchorMode) => void;
  isCreating: boolean;
}

export default function AXISAnchorEditor({
  initialValue = '',
  initialMode,
  onSave,
  isCreating,
}: AXISAnchorEditorProps) {
  const [content, setContent] = useState(initialValue.slice(0, MAX_ANCHOR_LENGTH));
  const [mode, setMode] = useState<AXISAnchorMode | undefined>(initialMode);

  const canSave = content.trim().length > 20 && content.length <= MAX_ANCHOR_LENGTH;

  return (
    <div className="space-y-5">
      <div>
        <label className="block text-sm font-semibold text-amber-200 mb-3 uppercase tracking-wider">
          {isCreating ? 'Create Your Identity Anchor' : 'Edit Your Identity Anchor'}
        </label>
        <p className="text-xs text-slate-500 mb-3">
          A free-text description of who you are. Include values, life context, preferences for interaction, constraints.
        </p>
        <textarea
          value={content}
          onChange={(e) => {
            const newValue = e.target.value.slice(0, MAX_ANCHOR_LENGTH);
            setContent(newValue);
          }}
          placeholder="I'm a 34-year-old engineer navigating career transition. I value directness and dislike platitudes. Working on being less conflict-avoidant."
          rows={4}
          className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-600 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-colors resize-none"
        />
        <div className="flex justify-between items-end mt-2">
          <p className="text-xs text-slate-500">
            {content.length} / {MAX_ANCHOR_LENGTH} characters
          </p>
          {content.length < 20 && content.length > 0 && (
            <p className="text-xs text-amber-600">(minimum 20 characters)</p>
          )}
        </div>
      </div>

      {/* Mode Picker */}
      <div>
        <label className="block text-xs font-semibold text-slate-400 mb-2 uppercase tracking-wider">
          Focus Mode <span className="text-slate-600 normal-case font-normal">(optional)</span>
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {ANCHOR_MODES.map((m) => (
            <button
              key={m.value}
              type="button"
              onClick={() => setMode(mode === m.value ? undefined : m.value)}
              className={`text-left px-3 py-2.5 rounded-lg border transition-colors ${
                mode === m.value
                  ? 'border-amber-500/60 bg-amber-950/30 text-amber-200'
                  : 'border-slate-700 bg-slate-900/40 text-slate-400 hover:border-slate-600 hover:text-slate-300'
              }`}
            >
              <p className="text-xs font-semibold mb-0.5">{m.label}</p>
              <p className="text-xs opacity-70 leading-snug">{m.description}</p>
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={() => onSave(content, mode)}
        disabled={!canSave}
        className="w-full px-4 py-2 bg-amber-600 text-amber-50 rounded-lg hover:bg-amber-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium text-sm"
      >
        {isCreating ? 'Create Anchor' : 'Save Changes'}
      </button>
    </div>
  );
}

/**
 * AXIS RPL Banner
 * Pattern detection banner - dismissible
 */

import React, { useState } from 'react';
import { AlertCircle, X } from 'lucide-react';
import type { RPLTrigger } from '../hooks/useAXISRPL';
import { setRPLCooldown } from '../hooks/useAXISRPL';

interface AXISRPLBannerProps {
  trigger: RPLTrigger;
  onDismiss: () => void;
}

export default function AXISRPLBanner({ trigger, onDismiss }: AXISRPLBannerProps) {
  const [isDismissed, setIsDismissed] = useState(false);

  const handleDismiss = () => {
    setRPLCooldown(trigger.type);
    setIsDismissed(true);
    onDismiss();
  };

  if (isDismissed) return null;

  const getBgColor = (type: RPLTrigger['type']) => {
    switch (type) {
      case 'anchor-review':
        return 'bg-amber-950/40 border-amber-900/50';
      case 'title-repetition':
        return 'bg-orange-950/40 border-orange-900/50';
      case 'high-frequency':
        return 'bg-rose-950/40 border-rose-900/50';
      case 'open-accumulation':
        return 'bg-violet-950/40 border-violet-900/50';
      default:
        return 'bg-slate-900/40 border-slate-800/50';
    }
  };

  const getTextColor = (type: RPLTrigger['type']) => {
    switch (type) {
      case 'anchor-review':
        return 'text-amber-200';
      case 'title-repetition':
        return 'text-orange-200';
      case 'high-frequency':
        return 'text-rose-200';
      case 'open-accumulation':
        return 'text-violet-200';
      default:
        return 'text-slate-300';
    }
  };

  return (
    <div className={`border rounded-lg p-4 ${getBgColor(trigger.type)}`}>
      <div className="flex gap-3">
        <AlertCircle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${getTextColor(trigger.type)}`} />
        <div className="flex-1">
          <p className={`text-sm font-semibold ${getTextColor(trigger.type)} mb-1`}>
            {trigger.message}
          </p>
          <p className={`text-sm ${getTextColor(trigger.type)} opacity-80`}>
            {trigger.question}
          </p>
        </div>
        <button
          onClick={handleDismiss}
          className={`flex-shrink-0 ${getTextColor(trigger.type)} opacity-60 hover:opacity-100 transition-opacity`}
        >
          <X size={18} />
        </button>
      </div>
    </div>
  );
}

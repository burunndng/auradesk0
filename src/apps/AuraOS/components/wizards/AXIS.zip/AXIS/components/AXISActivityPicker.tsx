/**
 * AXIS Activity Picker
 * Radio group for selecting activity type
 */

import React from 'react';
import type { AXISActivityType } from '../../../../types';

interface AXISActivityPickerProps {
  onSelect: (activity: AXISActivityType) => void;
  selectedValue?: AXISActivityType | null;
}

const ACTIVITIES: Array<{ value: AXISActivityType; label: string; description: string }> = [
  {
    value: 'ai-conversation',
    label: 'Have an AI conversation',
    description: 'ChatGPT, Claude, or other AI chat',
  },
  {
    value: 'journal',
    label: 'Journal / write',
    description: 'Free writing or structured journaling',
  },
  {
    value: 'therapy',
    label: 'Therapy / coaching session',
    description: 'With a professional or mentor',
  },
  {
    value: 'difficult-conversation',
    label: 'Difficult conversation',
    description: 'A challenging interpersonal exchange',
  },
  {
    value: 'meditation',
    label: 'Meditation / contemplation',
    description: 'Sitting practice or walking meditation',
  },
  {
    value: 'other',
    label: 'Something else',
    description: 'Any reflective experience',
  },
];

export default function AXISActivityPicker({ onSelect, selectedValue }: AXISActivityPickerProps) {
  return (
    <div className="space-y-2">
      {ACTIVITIES.map((activity) => (
        <button
          key={activity.value}
          onClick={() => onSelect(activity.value)}
          className={`w-full text-left p-3 rounded-lg border transition-colors ${
            selectedValue === activity.value
              ? 'bg-amber-900/30 border-amber-700 text-amber-50'
              : 'bg-slate-900/50 border-slate-700 text-slate-300 hover:border-slate-600'
          }`}
        >
          <div className="flex items-center gap-2">
            <div className={`w-4 h-4 rounded-full border-2 transition-colors ${
              selectedValue === activity.value
                ? 'bg-amber-600 border-amber-600'
                : 'border-slate-600'
            }`} />
            <div>
              <p className="text-sm font-medium">{activity.label}</p>
              <p className={`text-xs ${selectedValue === activity.value ? 'text-amber-200' : 'text-slate-500'}`}>
                {activity.description}
              </p>
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}

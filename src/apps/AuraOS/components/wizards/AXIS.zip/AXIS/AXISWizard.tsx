/**
 * AXIS Wizard
 * State machine managing the full session lifecycle
 */

import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import type { AXISSession, AXISActivityType, AXISReflection as AXISReflectionData, AXISConversationMessage, AXISSynthesisBrief } from '../../../types';
import { useAXISAnchor } from './hooks/useAXISAnchor';
import { useAXISSessions } from './hooks/useAXISSessions';
import { useAXISRPL } from './hooks/useAXISRPL';
import { createAXISInsight, loadPreviousSynthesis } from '../../../services/AXISService';
import AXISDashboard from './views/AXISDashboard';
import AXISFraming from './views/AXISFraming';
import AXISBridge from './views/AXISBridge';
import AXISWaiting from './views/AXISWaiting';
import AXISReflectionView from './views/AXISReflection';
import AXISClosure from './views/AXISClosure';
import AXISHistory from './views/AXISHistory';
import AXISRPLBanner from './components/AXISRPLBanner';
import AXISModePicker from './views/AXISModePicker';
import AXISLiveSession from './views/AXISLiveSession';
import AXISSynthesis from './views/AXISSynthesis';
import AXISMetaSynthesisView from './views/AXISMetaSynthesis';

// Logic steps for the wizard state machine
type Step = 'dashboard' | 'anchor-create' | 'mode-picker' | 'framing' | 'bridge' | 'live-session' | 'synthesis' | 'waiting' | 'reflection' | 'closure' | 'history' | 'meta-synthesis';

interface AXISWizardProps {
  userId: string;
  authUserId?: string;
  onClose: () => void;
}

export default function AXISWizard({ userId, authUserId, onClose }: AXISWizardProps) {
  const [currentStep, setCurrentStep] = useState<Step>('dashboard');
  const [currentSession, setCurrentSession] = useState<AXISSession | null>(null);
  const [isOffAxisMode, setIsOffAxisMode] = useState(false);
  const [dismissedRPL, setDismissedRPL] = useState<any>(null);
  const [contextData, setContextData] = useState<any>(null);
  const [refinedIntention, setRefinedIntention] = useState('');
  const [preparationHistory, setPreparationHistory] = useState<AXISConversationMessage[]>([]);
  const [conversationHistory, setConversationHistory] = useState<AXISConversationMessage[]>([]);
  const [previousSynthesis, setPreviousSynthesis] = useState<AXISSynthesisBrief | null>(null);

  // Data hooks
  const { anchor, hasAnchor, saveAnchor, createAnchor } = useAXISAnchor();
  const {
    sessions = [],
    createSession,
    updateSessionStatus,
    updateRefinedIntention,
    updateSessionData,
    linkInsight
  } = useAXISSessions();

  const lastSessionDate = sessions
    .filter(s => s.status === 'closed' && !s.isOffAxis)
    .sort((a, b) => new Date(b.closedAt ?? b.createdAt).getTime() - new Date(a.closedAt ?? a.createdAt).getTime())[0]?.closedAt;

  const rplTrigger = useAXISRPL(sessions, anchor?.updatedAt, lastSessionDate);

  // Load previous synthesis on mount — auth users from Supabase, anon from localStorage
  useEffect(() => {
    const idToLoad = authUserId || userId;
    loadPreviousSynthesis(idToLoad).then(setPreviousSynthesis).catch(console.error);
  }, [authUserId, userId]);

  // Transition Handlers
  const handleStartFraming = () => {
    setIsOffAxisMode(false);
    setCurrentStep('framing');
  };

  const handleStartOffAxis = () => {
    setIsOffAxisMode(true);
    setCurrentStep('framing');
  };

  const handleFramingComplete = (title: string, intention: string, successCriteria?: string, activityType?: AXISActivityType, contextInfo?: any) => {
    // Reuse existing session if framing was re-submitted (e.g. back from mode-picker)
    // to avoid orphaned active sessions in localStorage
    if (currentSession) {
      updateSessionStatus(currentSession.id, 'closed');
    }
    const session = createSession(activityType || 'other', title, intention, successCriteria);
    const sessionWithContext = {
      ...session,
      ...(contextInfo ? { contextData: contextInfo } : {}),
      ...(isOffAxisMode ? { isOffAxis: true } : {}),
    };
    setCurrentSession(sessionWithContext);
    setContextData(contextInfo);
    
    // Explicitly persist contextData so it's not lost on reload
    if (contextInfo) {
      updateSessionData(session.id, { contextData: contextInfo });
    }

    if (activityType === 'ai-conversation') {
      setCurrentStep('mode-picker');
    } else {
      setCurrentStep('waiting');
    }
  };

  const handleBridgeComplete = () => {
    setCurrentStep('waiting');
  };

  const handleReadyToReflect = () => {
    setCurrentStep('reflection');
  };

  const handleReflectionComplete = (reflection: AXISReflectionData) => {
    if (!currentSession) return;
    try {
      const insight = createAXISInsight(currentSession, reflection, userId, authUserId);
      linkInsight(currentSession.id, insight.id);
      updateSessionStatus(currentSession.id, 'reflecting');
      setCurrentStep('closure');
    } catch (e) {
      console.error('[AXIS] Error completing reflection:', e);
    }
  };

  const handleCloseSession = () => {
    if (currentSession) {
      updateSessionStatus(currentSession.id, 'closed');
    }
    setCurrentStep('dashboard');
    setCurrentSession(null);
  };

  const handleKeepOpen = () => {
    setCurrentStep('dashboard');
    setCurrentSession(null);
  };

  const handleStartNative = () => {
    // Guard: anchor must exist before entering native flow
    if (!hasAnchor) {
      setCurrentStep('anchor-create');
      return;
    }
    // We used to route first-time users to 'preparation' here, 
    // but the framing screen now collects enough context.
    // Go straight to live session.
    if (currentSession) {
      setCurrentSession({ ...currentSession, refinedIntention: currentSession.intention });
    }
    setRefinedIntention(currentSession?.intention ?? '');
    setCurrentStep('live-session');
  };

  const handlePreparationComplete = (intention: string, history: AXISConversationMessage[]) => {
    setRefinedIntention(intention);
    setPreparationHistory(history);
    if (currentSession) {
      updateRefinedIntention(currentSession.id, intention);
      updateSessionData(currentSession.id, { preparationHistory: history, refinedIntention: intention });
      setCurrentSession({ ...currentSession, refinedIntention: intention });
    }
    setCurrentStep('live-session');
  };

  const handleSessionEnd = (history: AXISConversationMessage[]) => {
    setConversationHistory(history);
    if (currentSession) {
      updateSessionData(currentSession.id, { conversationHistory: history });
    }
    setCurrentStep('synthesis');
  };

  const handleSynthesisComplete = (brief: AXISSynthesisBrief) => {
    if (currentSession) {
      updateSessionStatus(currentSession.id, 'closed');
    }
    setPreviousSynthesis(brief);
    setCurrentSession(null);
    setRefinedIntention('');
    setPreparationHistory([]);
    setConversationHistory([]);

    // Meta-Mirror: trigger after every 5th closed non-off-axis session
    const closedCount = sessions.filter(s => s.status === 'closed' && !s.isOffAxis).length;
    const isMultipleOfFive = closedCount > 0 && closedCount % 5 === 0;
    if (isMultipleOfFive && !currentSession?.isOffAxis) {
      setCurrentStep('meta-synthesis');
    } else {
      setCurrentStep('dashboard');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-0 sm:p-4 md:p-6" style={{ height: '100dvh' }}>
      <div className="bg-slate-900 border-x border-slate-800 sm:border w-full max-w-4xl h-[100dvh] sm:h-auto sm:max-h-[90vh] rounded-none sm:rounded-2xl shadow-2xl flex flex-col overflow-hidden">

        {/* Accessible label for screen readers */}
        <h2 className="sr-only">AXIS Session Wizard</h2>

        {/* Header */}
        <div className="flex items-center justify-between gap-2 px-3 sm:px-4 py-3 sm:py-4 border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-20">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
            <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-lg bg-teal-500/20 flex items-center justify-center shrink-0">
              <div className="w-3 h-3 sm:w-4 sm:h-4 rounded-full border-2 border-teal-400" />
            </div>
            <h1 className="text-base sm:text-xl font-semibold text-slate-100 truncate">AXIS</h1>
          </div>
          <button
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center hover:bg-slate-800 rounded-full transition-colors text-slate-400 hover:text-slate-100 shrink-0 -mr-1 sm:mr-0"
            aria-label="Close AXIS wizard"
          >
            <X size={20} />
          </button>
        </div>

        {/* View Container */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6" style={{ WebkitOverflowScrolling: 'touch' }}>
          {/* Real-time Practice Lever (RPL) Banner */}
          {currentStep === 'dashboard' && rplTrigger && dismissedRPL !== rplTrigger && (
            <div className="mb-6">
              <AXISRPLBanner
                trigger={rplTrigger}
                onDismiss={() => setDismissedRPL(rplTrigger)}
              />
            </div>
          )}

          {currentStep === 'dashboard' && (
            <AXISDashboard
              anchor={anchor}
              hasAnchor={hasAnchor}
              sessionCount={sessions?.length || 0}
              openSessionCount={(sessions || []).filter(s => s.status !== 'closed').length}
              previousSynthesis={previousSynthesis}
              onStartFraming={handleStartFraming}
              onStartNative={handleStartNative}
              onStartOffAxis={handleStartOffAxis}
              onViewHistory={() => setCurrentStep('history')}
              onCreateAnchor={createAnchor}
              onEditAnchor={saveAnchor}
            />
          )}

          {currentStep === 'framing' && (
            <AXISFraming
              onComplete={handleFramingComplete}
              onBack={() => setCurrentStep('dashboard')}
              previousSynthesis={previousSynthesis}
            />
          )}

          {currentStep === 'bridge' && currentSession && (
            <AXISBridge
              session={currentSession}
              onComplete={handleBridgeComplete}
              onBack={() => setCurrentStep('framing')}
              contextData={contextData}
            />
          )}

          {currentStep === 'mode-picker' && anchor && (
            <AXISModePicker
              previousSynthesis={previousSynthesis}
              onStartNative={handleStartNative}
              onStartBridge={() => setCurrentStep('bridge')}
              onBack={() => setCurrentStep('framing')}
            />
          )}

          {currentStep === 'live-session' && currentSession && anchor && (
            <AXISLiveSession
              anchor={anchor}
              intention={refinedIntention || currentSession.intention}
              successCriteria={currentSession.successCriteria}
              activityType={currentSession.activityType}
              previousSynthesis={previousSynthesis}
              preparationHistory={preparationHistory}
              contextData={contextData}
              sessionCount={sessions.filter(s => s.status === 'closed' && !s.isOffAxis).length}
              lastSessionDate={sessions.filter(s => s.status === 'closed' && !s.isOffAxis).sort((a, b) => new Date(b.closedAt ?? b.createdAt).getTime() - new Date(a.closedAt ?? a.createdAt).getTime())[0]?.closedAt}
              isOffAxis={currentSession?.isOffAxis}
              onSessionEnd={handleSessionEnd}
              onBack={() => setCurrentStep('mode-picker')}
            />
          )}

          {currentStep === 'synthesis' && currentSession && anchor && (
            <AXISSynthesis
              session={{ ...currentSession, preparationHistory }}
              anchor={anchor}
              conversationHistory={conversationHistory}
              userId={authUserId || userId}
              previousSynthesis={previousSynthesis}
              onComplete={handleSynthesisComplete}
            />
          )}

          {currentStep === 'waiting' && currentSession && (
            <AXISWaiting
              session={currentSession}
              onReady={handleReadyToReflect}
              onBack={() => setCurrentStep(currentSession.activityType === 'ai-conversation' ? 'bridge' : 'framing')}
              onCancel={() => {
                setCurrentStep('dashboard');
                setCurrentSession(null);
              }}
            />
          )}

          {currentStep === 'reflection' && currentSession && (
            <AXISReflectionView
              session={currentSession}
              anchorMode={anchor?.mode}
              onComplete={handleReflectionComplete}
              onBack={() => setCurrentStep('waiting')}
            />
          )}

          {currentStep === 'closure' && currentSession && (
            <AXISClosure
              session={currentSession}
              onClose={handleCloseSession}
              onKeepOpen={handleKeepOpen}
            />
          )}

          {currentStep === 'history' && (
            <AXISHistory
              sessions={sessions || []}
              onBack={() => setCurrentStep('dashboard')}
              onSelectSession={() => setCurrentStep('dashboard')}
            />
          )}

          {currentStep === 'meta-synthesis' && anchor && (
            <AXISMetaSynthesisView
              sessions={sessions || []}
              anchor={anchor}
              onComplete={() => setCurrentStep('dashboard')}
            />
          )}
        </div>
      </div>
    </div>
  );
}
